{{/*
Expand the name of the chart.
*/}}
{{- define "eyrie-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name: <release>-<chart>, truncated to 63 chars.
*/}}
{{- define "eyrie-agent.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart label (name-version).
*/}}
{{- define "eyrie-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels.
*/}}
{{- define "eyrie-agent.labels" -}}
helm.sh/chart: {{ include "eyrie-agent.chart" . }}
{{ include "eyrie-agent.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels.
*/}}
{{- define "eyrie-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eyrie-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Service account name.
*/}}
{{- define "eyrie-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "eyrie-agent.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/*
Name of the Secret that holds AGENT_TOKEN. Either the user-supplied
existingSecret, or a chart-managed Secret named <fullname>-token.
*/}}
{{- define "eyrie-agent.tokenSecretName" -}}
{{- if .Values.agent.existingSecret -}}
{{- .Values.agent.existingSecret -}}
{{- else -}}
{{- printf "%s-token" (include "eyrie-agent.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Key within the token Secret that holds AGENT_TOKEN. Matches
existingSecretKey, which also governs the chart-managed Secret.
*/}}
{{- define "eyrie-agent.tokenSecretKey" -}}
{{- default "token" .Values.agent.existingSecretKey -}}
{{- end -}}

{{/*
Comma-separated names pulled from .Values.imagePullSecrets (a list of
`{name: ...}` entries, the standard Helm convention), for the agent's
ROUTER_IMAGE_PULL_SECRETS env var -- the router Deployment it creates in the
workload namespace needs its own copy of these, since it does not share this
Deployment's imagePullSecrets. Empty when the list is empty.
*/}}
{{- define "eyrie-agent.imagePullSecretNames" -}}
{{- $names := list -}}
{{- range .Values.imagePullSecrets -}}
{{- $names = append $names .name -}}
{{- end -}}
{{- join "," $names -}}
{{- end -}}
